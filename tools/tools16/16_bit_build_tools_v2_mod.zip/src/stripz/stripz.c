/*
 *  Stripz.c - Strip the header off of a .SYS file
 *
 *  I don't know what this is for, but this program reads a file
 *  of the format
 *
 *  DW  <len>
 *  DB  <len-2> dup (0)
 *  DB  N bytes of data to keep
 *
 *  This program copies argv[1] to argv[2], striping off those leading
 *  bytes of zero and the length word.
 *
 *  We don't check to see if they're really zero, we just discard
 *  the first <len> bytes of argv[1].
 *
 *  moyefi 20-Oct-2020 Ported to Windows XP
 */

#pragma warning(disable : 4007)
#include <stdio.h>
#include<process.h>
#include <fcntl.h>
#include <sys\types.h>
#include  <sys\stat.h>
#include  <io.h>

char buf[16384];
long pos;
int rdcnt;
int srcfile, tgtfile ;

int main(int argc, char  *argv[])
{
  if ( argc != 3 ) {
    fprintf (stderr, "Usage : stripz src_file trgt_file\n");
    exit(1) ;
  }

  if ((srcfile = _open(argv[1], (O_BINARY | O_RDONLY))) == -1) {
    fprintf (stderr, "Error opening %s\n", argv[1]) ;
    exit(1) ;
  }

  rdcnt = _read(srcfile, buf, 2);
  if (rdcnt != 2) {
    fprintf (stderr, "Can't read %s\n", argv[1]);
    exit(1);
  }

  pos = _lseek (srcfile, 0L, SEEK_END ) ;
  if ( (long)(*(unsigned int *)buf) > pos ) {
    fprintf (stderr, "File too short or improper format.\n");
    exit(1);
  }

  _lseek(srcfile, (long)(*(unsigned int *)buf), SEEK_SET ) ;

  if ( (tgtfile = _open(argv[2], (O_BINARY|O_WRONLY|O_CREAT|O_TRUNC),
                      (S_IREAD|S_IWRITE))) == -1) {
    printf ("Error creating %s\n", argv[2]) ;
    _close (srcfile) ;
    exit(1) ;
  }

  while ( (rdcnt = _read(srcfile, buf, sizeof buf)) > 0)
    _write (tgtfile, buf, rdcnt);

  _close (srcfile) ;
  _close (tgtfile) ;

  return(0) ;
}